package com.harunaltun.finaluygulama





import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.PopupMenu
import android.widget.ProgressBar
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import kotlinx.android.synthetic.main.activity_main2.*
import kotlinx.android.synthetic.main.activity_main2.view.*
import kotlinx.android.synthetic.main.activity_main3.*
import kotlinx.android.synthetic.main.ozeluyari.*


class MainActivity3 : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)



        val tasarim=layoutInflater.inflate(R.layout.ozeluyari,null)
        val ozeluyaripenceresi=AlertDialog.Builder(this)
        ozeluyaripenceresi.setView(tasarim)
        var namee2=tasarim.findViewById<EditText>(R.id.name2)
        var passs2=tasarim.findViewById<EditText>(R.id.pass2)
        var progressBar3=tasarim.findViewById<ProgressBar>(R.id.progressBar3)
        var preferences=getSharedPreferences(dosyayolu, Context.MODE_PRIVATE)
        var editor=preferences.edit()

        button.setOnClickListener {
            val acilirmenu=PopupMenu(this,button)
            acilirmenu.menuInflater.inflate(R.menu.popupmenu,acilirmenu.menu)
            acilirmenu.setOnMenuItemClickListener { i->
                when(i.itemId){
                    R.id.rgb->{
                            fragmentcagir(BlankFragment2())
                    true}
                    R.id.snack->{
                        fragmentcagir(BlankFragment3())

                        true}
                    R.id.çıkış->{
                        ozeluyaripenceresi.create().show()

                   true}
                    else->false

                    }

            }
            acilirmenu.show()

        }

            passs2.addTextChangedListener(object :TextWatcher{
                override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

                }

                override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                    if(namee2.text.toString()=="Harun Altun"&& passs2.text.toString()=="02200201057"){
                        progressBar3.visibility=View.VISIBLE
                        editor.remove(anahatarisim)
                        editor.remove(anahtarsifre)
                        editor.remove(tick.toString())
                        editor.apply()
                        var gecis=Intent(this@MainActivity3,MainActivity2::class.java)
                        Handler().postDelayed({
                            startActivity(gecis)
                            finish()
                        },3000)
                    }
                }

                override fun afterTextChanged(p0: Editable?) {
                }

            })
        namee2.addTextChangedListener(object :TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                if(namee2.text.toString()=="Harun Altun"&& passs2.text.toString()=="02200201057"){
                    progressBar3.visibility=View.VISIBLE
                    editor.remove(anahatarisim)
                    editor.remove(anahtarsifre)
                    editor.remove(tick.toString())
                    editor.apply()
                    var gecis=Intent(this@MainActivity3,MainActivity2::class.java)
                    Handler().postDelayed({
                        startActivity(gecis)
                        finish()
                    },3000)
                }
            }

            override fun afterTextChanged(p0: Editable?) {
            }

        })



}

    fun fragmentcagir(cagrilanfragment :Fragment){
        var gecis =supportFragmentManager.beginTransaction()
        gecis.replace(R.id.fragmentContainerView,cagrilanfragment)
        gecis.commit()
    }



}


