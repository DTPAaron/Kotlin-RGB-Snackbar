package com.harunaltun.finaluygulama

import android.content.Context
import android.content.Intent
import android.opengl.Visibility
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main2.*

val dosyayolu="com.harunaltun.finaluygulama"
var anahatarisim="isim"
var anahtarsifre="şifre"
var tick =false

class MainActivity2 : AppCompatActivity(), TextWatcher {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val preferences=getSharedPreferences(dosyayolu,Context.MODE_PRIVATE)

        setContentView(R.layout.activity_main2)

        Toast.makeText(applicationContext,"Kaydedilmiş\r\n İsim: ${preferences.getString(anahatarisim, "Değer Yok")}" +
                "\r\nŞifre:${preferences.getString(anahtarsifre,"Değer Yok")}" +
                "\r\nUnutma:${preferences.getBoolean(tick.toString(),false)}",Toast.LENGTH_LONG).show()

        switch1.setChecked(preferences.getBoolean(tick.toString(),false))
        name.setText(preferences.getString(anahatarisim,""))
        pass.setText(preferences.getString(anahtarsifre,""))
        if(name.text.toString()=="Harun Altun"&&pass.text.toString()=="02200201057"){
            progressBar2.visibility=View.VISIBLE
            var gecis=Intent(this,MainActivity3::class.java)
            Handler().postDelayed({
                startActivity(gecis)
                finish()
            },3000)
        }
        name.addTextChangedListener(this)
        pass.addTextChangedListener(this)

    }

    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {

    }

    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        if(name.text.toString()=="Harun Altun"&& pass.text.toString()=="02200201057"){
        progressBar2.visibility=View.VISIBLE
        if(switch1.isChecked==true){
            var preferences=getSharedPreferences(dosyayolu,Context.MODE_PRIVATE)
            var editor=preferences.edit()
            editor.putString(anahatarisim,name.text.toString())
            editor.putString(anahtarsifre,pass.text.toString())
            switch1.isChecked=true
            editor.putBoolean(tick.toString(),switch1.isChecked)
            editor.apply()
        } else{
            anahatarisim="Değer Yok"
            anahtarsifre="Değer Yok"
        }
        var gecis=Intent(this,MainActivity3::class.java)
        Handler().postDelayed({
            startActivity(gecis)
            finish()
        },3000)
    }
    }

    override fun afterTextChanged(p0: Editable?) {

    }


}


